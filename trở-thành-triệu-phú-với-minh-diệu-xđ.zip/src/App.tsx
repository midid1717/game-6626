/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Coins, 
  History, 
  Users, 
  Timer, 
  Trophy,
  AlertCircle,
  ChevronRight,
  Heart,
  Flower,
  Sparkles,
  Star,
  Volume2,
  VolumeX
} from 'lucide-react';

// Sound URLs
const SOUNDS = {
  SHAKE: 'https://assets.mixkit.co/active_storage/sfx/2014/2014-preview.mp3', // Magic sparkle (cute)
  WIN: 'https://assets.mixkit.co/active_storage/sfx/2017/2017-preview.mp3',
  BET: 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3',
  FAIL: 'https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3',
  JOIN: 'https://assets.mixkit.co/active_storage/sfx/2018/2018-preview.mp3',
};

// Symbols mapping
const SYMBOLS = [
  { id: 'bau', name: 'Bầu', icon: '🎃', color: 'bg-orange-100' },
  { id: 'cua', name: 'Cua', icon: '🦀', color: 'bg-red-100' },
  { id: 'ca', name: 'Cá', icon: '🐟', color: 'bg-blue-100' },
  { id: 'ga', name: 'Gà', icon: '🐓', color: 'bg-yellow-100' },
  { id: 'tom', name: 'Tôm', icon: '🦐', color: 'bg-pink-100' },
  { id: 'nai', name: 'Nai', icon: '🦌', color: 'bg-amber-100' },
];

interface Player {
  id: string;
  name: string;
  avatar: string;
  netProfit: number;
  bets: Record<string, number>;
  isReady: boolean;
  lastWin: number;
}

interface GameState {
  status: 'BETTING' | 'SHAKING' | 'RESULT' | 'GAME_OVER';
  timer: number;
  results: string[];
  history: string[][];
  players: Player[];
  totalBets: Record<string, number>;
  gmBalance: number;
  isGmSet: boolean;
}

export default function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [name, setName] = useState('');
  const [joined, setJoined] = useState(false);
  const [currentBets, setCurrentBets] = useState<Record<string, number>>({});
  const [error, setError] = useState<string | null>(null);
  const [gmBalanceInput, setGmBalanceInput] = useState('200000');
  const [isMuted, setIsMuted] = useState(false);

  const playSound = useCallback((soundUrl: string) => {
    if (isMuted) return;
    const audio = new Audio(soundUrl);
    audio.play().catch(e => console.log('Audio play blocked:', e));
  }, [isMuted]);

  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    newSocket.on('gameUpdate', (state: GameState) => {
      setGameState(prev => {
        // Trigger sounds based on state transitions
        if (state.status === 'SHAKING' && prev?.status !== 'SHAKING') {
          playSound(SOUNDS.SHAKE);
        }
        if (state.status === 'RESULT' && prev?.status !== 'RESULT') {
          const meInState = state.players.find(p => p.id === newSocket.id);
          if (meInState && meInState.lastWin > 0) {
            playSound(SOUNDS.WIN);
          }
        }
        if (state.status === 'GAME_OVER' && prev?.status !== 'GAME_OVER') {
          playSound(SOUNDS.FAIL);
        }
        return state;
      });
    });

    newSocket.on('error', (msg: string) => {
      setError(msg);
      setTimeout(() => setError(null), 3000);
    });

    return () => {
      newSocket.close();
    };
  }, []);

  const handleJoin = () => {
    if (socket && name.trim()) {
      socket.emit('join', { name, avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}` });
      setJoined(true);
      playSound(SOUNDS.JOIN);
    }
  };

  const handleSetGmBalance = () => {
    if (socket && gmBalanceInput) {
      socket.emit('setGmBalance', parseInt(gmBalanceInput));
    }
  };

  const placeBet = (symbol: string, amount: number) => {
    const me = gameState?.players.find(p => p.id === socket?.id);
    if (gameState?.status !== 'BETTING' || me?.isReady) return;
    setCurrentBets(prev => ({
      ...prev,
      [symbol]: (prev[symbol] || 0) + amount
    }));
    playSound(SOUNDS.BET);
  };

  const handleConfirmBet = () => {
    if (socket && Object.keys(currentBets).length > 0) {
      socket.emit('placeBet', currentBets);
      setCurrentBets({});
    }
  };

  const handleClearBets = () => {
    if (!me?.isReady) {
      setCurrentBets({});
    }
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('vi-VN') + ' VNĐ';
  };

  const formatProfit = (amount: number) => {
    const sign = amount > 0 ? '+' : '';
    return sign + amount.toLocaleString('vi-VN');
  };

  if (!joined) {
    return (
      <div className="min-h-screen bg-[#FFB6C1] flex items-center justify-center p-4 font-sans relative overflow-hidden">
        {/* Floating background elements */}
        <motion.div 
          animate={{ y: [0, -20, 0], rotate: [0, 10, 0], scale: [1, 1.1, 1] }}
          transition={{ duration: 5, repeat: Infinity }}
          className="absolute top-10 left-10 text-white/30"
        >
          <Heart size={80} fill="currentColor" />
        </motion.div>
        <motion.div 
          animate={{ y: [0, 20, 0], rotate: [0, -10, 0], scale: [1, 0.9, 1] }}
          transition={{ duration: 4, repeat: Infinity }}
          className="absolute bottom-10 right-10 text-white/30"
        >
          <Flower size={100} fill="currentColor" />
        </motion.div>
        <motion.div 
          animate={{ x: [0, 30, 0], y: [0, -30, 0] }}
          transition={{ duration: 6, repeat: Infinity }}
          className="absolute top-1/4 right-1/4 text-white/20"
        >
          <Sparkles size={60} />
        </motion.div>
        <motion.div 
          animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="absolute bottom-1/4 left-1/4 text-white/20"
        >
          <Star size={50} fill="currentColor" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/90 backdrop-blur-md p-8 rounded-[40px] shadow-2xl max-w-md w-full border-8 border-[#FF69B4]/20 relative z-10"
        >
          <div className="flex justify-center mb-4">
            <div className="bg-[#FF69B4] p-4 rounded-full shadow-lg">
              <Sparkles className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-4xl font-black text-[#D02090] text-center mb-2 uppercase tracking-tight text-3d">
            Minh Diệu xđ
          </h1>
          <p className="text-[#FF69B4] text-center mb-8 font-medium italic">Sòng bài kẹo ngọt 🌸</p>
          
          <div className="space-y-6">
            <div>
              <label className="block text-[#D02090] font-bold mb-2 uppercase text-xs tracking-widest">Biệt danh của bạn</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nhập tên đáng yêu..."
                className="w-full p-4 rounded-2xl border-2 border-[#FFB6C1] bg-white text-[#D02090] focus:outline-none focus:ring-4 focus:ring-[#FFB6C1]/50 placeholder-[#FFB6C1]"
              />
            </div>
            <button 
              onClick={handleJoin}
              disabled={!name.trim()}
              className="w-full pink-button text-white font-black py-4 rounded-2xl transition-all uppercase tracking-widest shadow-lg disabled:opacity-50 text-lg"
            >
              Vào Chơi Thôi! ✨
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (gameState && !gameState.isGmSet) {
    return (
      <div className="min-h-screen bg-[#FFF0F5] flex items-center justify-center p-4 font-sans relative overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-md p-8 rounded-[40px] shadow-2xl max-w-md w-full border-8 border-[#FF69B4]/20 relative z-10 text-center"
        >
          <div className="w-24 h-24 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6 border-4 border-[#FF69B4]">
            <span className="text-5xl">👸</span>
          </div>
          <h2 className="text-2xl font-black text-[#D02090] mb-2 uppercase">Thiết lập Quản trò</h2>
          <p className="text-[#FF69B4] mb-6 font-medium italic">"Bà chủ XH đen với khuôn mặt thiên thần" 🌸</p>
          
          <div className="space-y-6 text-left">
            <div>
              <label className="block text-[#D02090] font-bold mb-2 uppercase text-xs tracking-widest">Số tiền Bà chủ mang theo (VNĐ)</label>
              <input 
                type="number" 
                value={gmBalanceInput}
                onChange={(e) => setGmBalanceInput(e.target.value)}
                className="w-full p-4 rounded-2xl border-2 border-[#FFB6C1] bg-white text-[#D02090] focus:outline-none focus:ring-4 focus:ring-[#FFB6C1]/50"
              />
            </div>
            <button 
              onClick={handleSetGmBalance}
              className="w-full pink-button text-white font-black py-4 rounded-2xl transition-all uppercase tracking-widest shadow-lg text-lg"
            >
              Bắt Đầu Cuộc Chơi! 🎀
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (gameState?.status === 'GAME_OVER') {
    return (
      <div className="min-h-screen bg-[#D02090] flex items-center justify-center p-4 font-sans relative overflow-hidden">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-10 rounded-[50px] shadow-2xl max-w-lg w-full text-center border-8 border-white/30"
        >
          <div className="text-8xl mb-6">💸</div>
          <h1 className="text-4xl font-black text-[#D02090] mb-4 uppercase tracking-tighter">Bà chủ hết tiền rồi!</h1>
          <p className="text-[#FF69B4] text-lg mb-8 font-bold italic">
            "Bà chủ XH đen với khuôn mặt thiên thần" đã cạn kiệt ngân khố để trả cho các bạn yêu rồi... 🌸
          </p>
          <div className="bg-pink-50 p-6 rounded-3xl mb-8 border-2 border-dashed border-[#FFB6C1]">
            <p className="text-sm text-[#D02090] font-bold uppercase mb-2">Tổng kết sòng bài</p>
            <div className="space-y-2">
              {gameState.players.map(p => (
                <div key={p.id} className="flex justify-between items-center">
                  <span className="font-bold text-[#FF69B4]">{p.name}</span>
                  <span className={`font-black ${p.netProfit > 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {formatProfit(p.netProfit)}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <button 
            onClick={() => setGmBalanceInput('200000')} // Reset input for next time
            onDoubleClick={handleSetGmBalance} // Double click to quickly restart if you are the one who can
            className="w-full pink-button text-white font-black py-4 rounded-2xl transition-all uppercase tracking-widest shadow-lg text-lg"
          >
            Chơi Lại Từ Đầu 🎀
          </button>
          <p className="mt-4 text-xs text-[#FFB6C1] font-medium italic">Nhấp đúp để Bà chủ nạp thêm tiền (Chỉ dành cho người quản lý)</p>
        </motion.div>
      </div>
    );
  }

  const me = gameState?.players.find(p => p.id === socket?.id);

  return (
    <div className="min-h-screen bg-[#FFF0F5] text-[#D02090] font-sans overflow-x-hidden pb-24">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md p-4 shadow-md border-b-2 border-[#FFB6C1] sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-[#FF69B4] p-2 rounded-2xl shadow-sm">
              <Heart size={20} className="text-white" fill="currentColor" />
            </div>
            <h1 className="font-black text-lg hidden sm:block uppercase tracking-tight text-[#D02090]">Minh Diệu xđ</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-full bg-[#FFB6C1]/20 border border-[#FFB6C1] text-[#D02090] hover:bg-[#FFB6C1]/40 transition-all"
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-bold uppercase text-[#FF69B4] tracking-widest">Ngân khố Bà chủ</span>
              <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-full border border-[#FFB6C1] shadow-sm">
                <span className="text-xs font-black text-[#D02090]">{formatCurrency(gameState?.gmBalance || 0)}</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-[#FFB6C1]/20 px-4 py-2 rounded-full border border-[#FFB6C1]">
              <Coins size={18} className="text-[#FF69B4]" />
              <span className={`font-black ${me?.netProfit && me.netProfit > 0 ? 'text-green-500' : me?.netProfit && me.netProfit < 0 ? 'text-red-500' : 'text-[#D02090]'}`}>
                {formatProfit(me?.netProfit || 0)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <img src={me?.avatar} alt="avatar" className="w-10 h-10 rounded-full border-2 border-[#FF69B4] bg-white shadow-sm" />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Game Status & Timer */}
        <div className="flex flex-col items-center justify-center py-6 relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-64 bg-[#FF69B4]/10 rounded-full blur-3xl -z-10" />
          
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <Timer className={`${gameState?.status === 'BETTING' ? 'text-pink-500' : 'text-purple-500'}`} />
            </motion.div>
            <span className="text-2xl font-black tracking-tight uppercase text-[#D02090]">
              {gameState?.status === 'BETTING' ? 'Đến giờ đặt cược 🌸' : 
               gameState?.status === 'SHAKING' ? 'Đang lắc kẹo...' : 'Kết quả nè! ✨'}
            </span>
          </div>

          {gameState?.status !== 'BETTING' && (
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="48" cy="48" r="44"
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="6"
                  className="text-[#FFB6C1]/30"
                />
                <circle
                  cx="48" cy="48" r="44"
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="6"
                  strokeDasharray={276}
                  strokeDashoffset={276 - (276 * (gameState?.timer || 0)) / (gameState?.status === 'RESULT' ? 5 : 5)}
                  className="text-[#FF69B4] transition-all duration-1000"
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute text-3xl font-black text-[#D02090]">{gameState?.timer}</span>
            </div>
          )}

          {gameState?.status === 'BETTING' && (
            <div className="text-center">
              <p className="text-sm font-bold text-[#FF69B4] italic">Đang chờ mọi người chốt đơn...</p>
              <div className="flex gap-2 mt-2">
                {gameState.players.map(p => (
                  <div key={p.id} className={`w-3 h-3 rounded-full ${p.isReady ? 'bg-pink-500' : 'bg-pink-200'}`} title={p.name} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Shaking Animation / Results */}
        <div className="flex flex-col items-center justify-center py-8 gap-6">
          <AnimatePresence mode="wait">
            {gameState?.status === 'SHAKING' ? (
              <motion.div
                key="shaking"
                animate={{ 
                  y: [0, -15, 0, -15, 0],
                  rotate: [0, -10, 10, -10, 10, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ repeat: Infinity, duration: 0.4 }}
                className="w-48 h-48 bg-white rounded-[60px] border-8 border-[#FFB6C1] shadow-2xl flex items-center justify-center relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white to-[#FFF0F5]" />
                <div className="absolute top-2 left-2 text-[#FFB6C1]/20"><Star fill="currentColor" size={24} /></div>
                <div className="absolute bottom-2 right-2 text-[#FFB6C1]/20"><Heart fill="currentColor" size={24} /></div>
                <motion.span 
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="text-7xl relative z-10"
                >
                  🎀
                </motion.span>
              </motion.div>
            ) : gameState?.status === 'RESULT' ? (
              <div className="flex flex-col items-center gap-6">
                <motion.div 
                  key="result"
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex gap-4"
                >
                  {gameState.results.map((res, i) => (
                    <motion.div
                      key={i}
                      initial={{ y: 30, opacity: 0, rotate: -10 }}
                      animate={{ y: 0, opacity: 1, rotate: 0 }}
                      transition={{ delay: i * 0.2, type: 'spring' }}
                      className="w-24 h-24 bg-white rounded-3xl border-4 border-[#FFB6C1] shadow-xl flex items-center justify-center text-5xl relative"
                    >
                      <div className="absolute -top-2 -right-2 text-pink-400"><Sparkles size={16} /></div>
                      {SYMBOLS.find(s => s.id === res)?.icon}
                    </motion.div>
                  ))}
                </motion.div>
                
                {me && me.lastWin > 0 && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0, y: 20 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    className="bg-white px-10 py-6 rounded-[40px] border-4 border-[#FF69B4] shadow-[0_10px_0_#FF69B4] relative overflow-hidden"
                  >
                    <div className="absolute -top-4 -left-4 text-pink-200 opacity-50"><Sparkles size={40} /></div>
                    <div className="absolute -bottom-4 -right-4 text-pink-200 opacity-50"><Heart size={40} fill="currentColor" /></div>
                    <p className="text-2xl font-black text-[#D02090] text-center relative z-10">
                      Chúc mừng bạn yêu! 🎉<br/>
                      <span className="text-pink-500 text-3xl">+{formatCurrency(me.lastWin)}</span> 🌸
                    </p>
                  </motion.div>
                )}
              </div>
            ) : (
              <div className="w-48 h-48 bg-white/40 rounded-[60px] border-4 border-dashed border-[#FFB6C1] flex items-center justify-center">
                <span className="text-[#FFB6C1] font-bold uppercase tracking-widest text-sm">Chờ lắc kẹo</span>
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Betting Board */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {SYMBOLS.map((symbol) => {
            const myBet = me?.bets[symbol.id] || 0;
            const currentPending = currentBets[symbol.id] || 0;
            const totalPool = gameState?.totalBets[symbol.id] || 0;
            const isReady = me?.isReady;
            
            return (
              <motion.div
                key={symbol.id}
                whileHover={!isReady ? { y: -8 } : {}}
                whileTap={!isReady ? { scale: 0.98 } : {}}
                onClick={() => !isReady && placeBet(symbol.id, 1000)}
                className={`relative p-6 rounded-[40px] transition-all overflow-hidden card-3d
                  ${(myBet > 0 || currentPending > 0) ? 'border-[#FF69B4] ring-4 ring-[#FF69B4]/20' : 'border-[#FFB6C1]'}
                  ${isReady ? 'opacity-80 cursor-not-allowed grayscale-[0.2]' : 'cursor-pointer'}`}
              >
                {/* Total Pool Badge */}
                {totalPool > 0 && (
                  <div className="absolute top-3 left-3 bg-[#FFB6C1]/30 text-[#D02090] px-2 py-0.5 rounded-full text-[9px] font-black border border-[#FFB6C1]/50">
                    Tổng: {totalPool.toLocaleString()}
                  </div>
                )}

                <div className="flex flex-col items-center gap-2">
                  <div className="w-24 h-24 bg-[#FFF0F5] rounded-full flex items-center justify-center mb-2 shadow-inner border-4 border-white">
                    <span className="text-6xl floating">{symbol.icon}</span>
                  </div>
                  <span className="font-black uppercase tracking-tight text-[#D02090] text-lg">{symbol.name}</span>
                  
                  <div className="flex flex-wrap justify-center gap-2 mt-3">
                    {[1000, 2000, 5000, 10000].map(amt => (
                      <button 
                        key={amt}
                        onClick={(e) => { e.stopPropagation(); !isReady && placeBet(symbol.id, amt); }}
                        disabled={isReady}
                        className="bg-white text-[#FF69B4] text-[10px] font-black px-3 py-1.5 rounded-full border-2 border-[#FFB6C1] hover:bg-[#FF69B4] hover:text-white hover:border-[#FF69B4] transition-all shadow-sm disabled:opacity-50"
                      >
                        {amt / 1000}k
                      </button>
                    ))}
                  </div>
                  {currentPending > 0 && (
                    <div className="mt-1">
                      <span className="text-xs text-pink-500 font-black">+{currentPending.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                {/* Bet Badges */}
                {(myBet > 0 || currentPending > 0) && (
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-3 right-3 bg-[#FF69B4] text-white px-3 py-1 rounded-full text-xs font-black shadow-md border-2 border-white"
                  >
                    {(myBet + currentPending).toLocaleString()}
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Action Bar */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-md p-4 border-t-2 border-[#FFB6C1] shadow-2xl z-50">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
            <button
              onClick={handleClearBets}
              disabled={gameState?.status !== 'BETTING' || Object.keys(currentBets).length === 0 || me?.isReady}
              className="bg-white text-[#FF69B4] px-6 py-4 rounded-2xl font-black uppercase tracking-widest border-2 border-[#FFB6C1] hover:bg-[#FFF0F5] transition-all disabled:opacity-30 text-sm"
            >
              Xóa Cược 🍬
            </button>
            
            <button
              onClick={handleConfirmBet}
              disabled={gameState?.status !== 'BETTING' || Object.keys(currentBets).length === 0 || me?.isReady}
              className={`pink-button text-white px-12 py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg flex items-center gap-2 text-lg
                ${me?.isReady ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {me?.isReady ? 'Đã Chốt! ✨' : 'Chốt Đơn! 🎀'}
            </button>
          </div>
        </div>

        {/* Players & History */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8">
          {/* Players List */}
          <div className="bg-white/60 p-6 rounded-[40px] border-2 border-[#FFB6C1] shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <Users size={20} className="text-[#FF69B4]" />
              <h2 className="font-black uppercase tracking-tight text-[#D02090]">Hội chị em ({gameState?.players.length}/4)</h2>
            </div>
            <div className="space-y-4">
              {gameState?.players.map(p => (
                <div key={p.id} className="flex items-center justify-between bg-white p-4 rounded-3xl border border-[#FFB6C1]/50 shadow-sm">
                  <div className="flex items-center gap-3">
                    <img src={p.avatar} alt="avatar" className="w-12 h-12 rounded-full bg-[#FFF0F5] border-2 border-[#FFB6C1]" />
                    <div>
                      <p className="font-black text-sm text-[#D02090]">{p.name} {p.id === socket?.id && '🌸'}</p>
                      <p className={`text-xs font-bold ${p.netProfit > 0 ? 'text-green-500' : p.netProfit < 0 ? 'text-red-500' : 'text-[#FF69B4]'}`}>
                        {formatProfit(p.netProfit)} Win
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {p.isReady && (
                      <div className="bg-pink-100 text-[#FF69B4] px-3 py-1 rounded-full text-[10px] font-black border border-[#FFB6C1]">
                        ĐÃ CHỐT ✨
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* History */}
          <div className="bg-white/60 p-6 rounded-[40px] border-2 border-[#FFB6C1] shadow-sm">
            <div className="flex items-center gap-2 mb-6">
              <History size={20} className="text-[#FF69B4]" />
              <h2 className="font-black uppercase tracking-tight text-[#D02090]">Nhật ký kẹo ngọt</h2>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {gameState?.history.map((h, i) => (
                <div key={i} className="flex gap-2 bg-white p-3 rounded-2xl border border-[#FFB6C1]/30 shadow-sm justify-center">
                  {h.map((res, j) => (
                    <span key={j} className="text-2xl">{SYMBOLS.find(s => s.id === res)?.icon}</span>
                  ))}
                </div>
              ))}
              {gameState?.history.length === 0 && (
                <div className="col-span-2 text-center text-sm text-[#FFB6C1] italic py-8">Chưa có kỉ niệm nào...</div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-28 left-1/2 -translate-x-1/2 bg-[#D02090] text-white px-8 py-4 rounded-full flex items-center gap-3 shadow-2xl z-[100] border-4 border-white"
          >
            <AlertCircle size={20} />
            <span className="font-black">{error}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
